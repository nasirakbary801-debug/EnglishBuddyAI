package com.englishbuddy.ai

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.RecognitionListener
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.graphics.Color
import android.text.InputType
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private val executor = Executors.newSingleThreadExecutor()
    private val history = JSONArray()
    private lateinit var chatBox: LinearLayout
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var tts: TextToSpeech
    private var speechRecognizer: SpeechRecognizer? = null
    private var ttsReady = false
    private val blue = Color.rgb(37, 99, 235)
    private val dark = Color.rgb(16, 35, 63)

    private val teacherPrompt = """
        You are English Buddy AI, a kind and patient English teacher for a beginner.
        The learner's preferred explanation language is Persian/Dari.
        Speak in very easy English, slowly and naturally. Ask only ONE question at a time.
        Let the learner answer before asking another question.
        Correct the learner's English gently. Show:
        1) Correct sentence in English.
        2) A short explanation in Persian/Dari.
        3) One simple example if useful.
        Keep replies short and encouraging. If the learner writes Persian, explain in Persian/Dari
        and guide them back to simple English practice. Do not overwhelm the learner.
    """.trimIndent()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildScreen()
        addMessage("teacher", "Hello! 👋 I am your English teacher. Let's practice together.\n\nFirst question: What is your name?")
        showApiKeyDialogIfMissing()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(245, 247, 251))
            layoutParams = LinearLayout.LayoutParams(-1, -1)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(18, 16, 14, 16)
            setBackgroundColor(dark)
        }
        val heading = TextView(this).apply {
            text = "English Buddy AI\nمعلم خصوصی انگلیسی"
            textSize = 19f
            setTextColor(Color.WHITE)
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        header.addView(heading, LinearLayout.LayoutParams(0, -2, 1f))
        val settings = Button(this).apply {
            text = "کلید API"
            textSize = 12f
            setOnClickListener { showApiKeyDialog() }
        }
        header.addView(settings)
        root.addView(header)

        status = TextView(this).apply {
            text = "برای مکالمه، پیام بنویس یا روی 🎙 بزن"
            textSize = 12f
            setTextColor(Color.DKGRAY)
            setPadding(14, 8, 14, 8)
        }
        root.addView(status)

        val scroll = ScrollView(this).apply {
            isFillViewport = true
        }
        chatBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 8, 12, 12)
        }
        scroll.addView(chatBox)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(8, 8, 8, 8)
            setBackgroundColor(Color.WHITE)
        }
        input = EditText(this).apply {
            hint = "پیام خود را بنویس..."
            textSize = 15f
            minLines = 1
            maxLines = 3
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            setPadding(12, 8, 12, 8)
        }
        bottom.addView(input, LinearLayout.LayoutParams(0, -2, 1f))

        val mic = Button(this).apply {
            text = "🎙"
            textSize = 18f
            setOnClickListener { startListening() }
        }
        bottom.addView(mic)

        val send = Button(this).apply {
            text = "ارسال"
            setOnClickListener { sendMessage() }
        }
        bottom.addView(send)
        root.addView(bottom)
        setContentView(root)
    }

    private fun addMessage(who: String, message: String) {
        val bubble = TextView(this).apply {
            text = (if (who == "teacher") "👩‍🏫 معلم:\n" else "🧑‍🎓 تو:\n") + message
            textSize = 15f
            setTextColor(if (who == "teacher") Color.rgb(30, 41, 59) else Color.WHITE)
            setPadding(14, 12, 14, 12)
            setBackgroundColor(if (who == "teacher") Color.WHITE else blue)
        }
        val params = LinearLayout.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.88).toInt(), -2
        ).apply {
            gravity = if (who == "teacher") Gravity.START else Gravity.END
            setMargins(0, 7, 0, 7)
        }
        chatBox.addView(bubble, params)

        if (who == "teacher") {
            val speak = Button(this).apply {
                text = "🔊 شنیدن پاسخ"
                textSize = 11f
                setOnClickListener { speak(message) }
            }
            val p = LinearLayout.LayoutParams(-2, -2).apply {
                gravity = Gravity.START
                bottomMargin = 8
            }
            chatBox.addView(speak, p)
        }
    }

    private fun sendMessage() {
        val message = input.text.toString().trim()
        if (message.isEmpty()) return
        val key = getSharedPreferences("settings", MODE_PRIVATE).getString("api_key", "") ?: ""
        if (key.isBlank()) {
            showApiKeyDialog()
            return
        }
        input.setText("")
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(input.windowToken, 0)
        addMessage("user", message)
        history.put(JSONObject().put("role", "user")
            .put("parts", JSONArray().put(JSONObject().put("text", message))))
        status.text = "معلم در حال فکر کردن است..."
        executor.execute {
            try {
                val answer = callGemini(key)
                history.put(JSONObject().put("role", "model")
                    .put("parts", JSONArray().put(JSONObject().put("text", answer))))
                runOnUiThread {
                    addMessage("teacher", answer)
                    status.text = "آماده برای پیام بعدی"
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "خطا در اتصال"
                    addMessage("teacher", "اتصال انجام نشد: ${e.message ?: "لطفاً اینترنت و API Key را بررسی کن."}")
                }
            }
        }
    }

    private fun callGemini(key: String): String {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-lite:generateContent?key=$key")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 30000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
        }
        val body = JSONObject()
            .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", teacherPrompt))))
            .put("contents", history)
            .put("generationConfig", JSONObject().put("temperature", 0.65).put("maxOutputTokens", 400))
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val response = stream.bufferedReader().use { it.readText() }
        conn.disconnect()
        val json = JSONObject(response)
        if (code !in 200..299) {
            val msg = json.optJSONObject("error")?.optString("message") ?: "HTTP $code"
            throw Exception(msg)
        }
        return json.getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
    }

    private fun showApiKeyDialogIfMissing() {
        val key = getSharedPreferences("settings", MODE_PRIVATE).getString("api_key", "")
        if (key.isNullOrBlank()) showApiKeyDialog()
    }

    private fun showApiKeyDialog() {
        val field = EditText(this).apply {
            hint = "کلید API را اینجا وارد کن"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(getSharedPreferences("settings", MODE_PRIVATE).getString("api_key", ""))
        }
        AlertDialog.Builder(this)
            .setTitle("راه‌اندازی هوش مصنوعی")
            .setMessage("برای فعال‌شدن معلم هوشمند، کلید رایگان Gemini API لازم است. راهنمای ساخت کلید در فایل README آمده است.")
            .setView(field)
            .setPositiveButton("ذخیره") { _, _ ->
                getSharedPreferences("settings", MODE_PRIVATE).edit()
                    .putString("api_key", field.text.toString().trim()).apply()
                status.text = "کلید ذخیره شد؛ حالا مکالمه را شروع کن."
            }
            .setNegativeButton("بعداً", null)
            .show()
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "تشخیص صدا در این گوشی در دسترس نیست."
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 101)
            return
        }
        try {
            speechRecognizer?.destroy()
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
            speechRecognizer?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { status.text = "گوش می‌دهم... انگلیسی صحبت کن." }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { status.text = "در حال تبدیل صدا به متن..." }
                override fun onError(error: Int) { status.text = "صدا تشخیص داده نشد؛ دوباره امتحان کن." }
                override fun onResults(results: Bundle?) {
                    val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (!words.isNullOrBlank()) {
                        input.setText(words)
                        input.setSelection(input.text.length)
                        status.text = "متن آماده است؛ برای ارسال دکمه ارسال را بزن."
                    }
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak in English")
            }
            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            status.text = "میکروفون آماده نشد."
        }
    }

    private fun speak(text: String) {
        if (ttsReady) {
            tts.language = Locale.US
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "teacher_reply")
        } else {
            status.text = "صدای گوشی هنوز آماده نیست."
        }
    }

    override fun onInit(statusCode: Int) {
        ttsReady = statusCode == TextToSpeech.SUCCESS
        if (ttsReady) tts.language = Locale.US
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        tts.stop()
        tts.shutdown()
        executor.shutdown()
        super.onDestroy()
    }
}
